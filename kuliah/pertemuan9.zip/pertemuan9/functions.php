<?php
// koneksi ke database
$conn = mysqli_connect("localhost","root","","phpdasar");


?>
